package com.ngonyama.app

import android.content.Context

data class Round(val ts: Long, val m: Double)

object Store {
    private const val P = "ng"
    private const val K = "rounds"

    fun all(c: Context): List<Round> {
        val s = c.getSharedPreferences(P, 0).getString(K, "") ?: ""
        return s.split("\n").mapNotNull { line ->
            val p = line.split(",")
            if (p.size != 2) return@mapNotNull null
            val t = p[0].toLongOrNull()
            val m = p[1].toDoubleOrNull()
            if (t == null || m == null) null else Round(t, m)
        }
    }

    fun add(c: Context, r: Round) {
        val sp = c.getSharedPreferences(P, 0)
        val cur = sp.getString(K, "") ?: ""
        val line = "${r.ts},${r.m}"
        sp.edit().putString(K, if (cur.isEmpty()) line else "$cur\n$line").apply()
    }

    fun clear(c: Context) {
        c.getSharedPreferences(P, 0).edit().remove(K).apply()
    }
}
