package com.ngonyama.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var out: TextView
    private var mode = 0
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            render()
            h.postDelayed(this, 2000)
        }
    }
    private val tf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        out = findViewById(R.id.out)
        findViewById<Button>(R.id.bAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.bStats).setOnClickListener { mode = 0; render() }
        findViewById<Button>(R.id.bHigh).setOnClickListener { mode = 1; render() }
        findViewById<Button>(R.id.bRules).setOnClickListener { mode = 2; render() }
        findViewById<Button>(R.id.bClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Delete all logged rounds?")
                .setPositiveButton("Delete") { _, _ -> Store.clear(this); render() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun enabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName)
    }

    private fun col(m: Double): Int = when {
        m >= 10 -> 0xFFFF4DD2.toInt()
        m >= 2 -> 0xFFB388FF.toInt()
        else -> 0xFF5AB8FF.toInt()
    }

    private fun SpannableStringBuilder.mult(m: Double) {
        val s = length
        append(String.format(Locale.US, "%.2fx", m))
        setSpan(ForegroundColorSpan(col(m)), s, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun mmss(sec: Long) = String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)
    private fun pct(a: Int, b: Int) = if (b == 0) "0%" else String.format(Locale.US, "%.1f%%", a * 100.0 / b)

    private fun render() {
        val rs = Store.all(this)
        val sb = SpannableStringBuilder()
        sb.append(if (enabled()) "Capture: ON\n\n" else "Capture: OFF - tap ACCESS and enable Ngonyama\n\n")
        when (mode) {
            0 -> stats(sb, rs)
            1 -> highs(sb, rs)
            else -> rules(sb, rs)
        }
        out.text = sb
    }

    private fun stats(sb: SpannableStringBuilder, rs: List<Round>) {
        sb.append("Rounds logged: ${rs.size}\n")
        if (rs.isEmpty()) {
            sb.append("Nothing yet. Turn capture on and open Aviator.\n")
            return
        }
        val hi = rs.filter { it.m >= 10 }
        sb.append("10x+ rounds: ${hi.size} (${pct(hi.size, rs.size)})\n")
        val gaps = hi.zipWithNext { a, b -> (b.ts - a.ts) / 1000 }.sorted()
        if (gaps.isNotEmpty()) {
            sb.append("Gap between 10x+ (min:sec)\n")
            sb.append("  shortest ${mmss(gaps.first())}\n")
            sb.append("  median   ${mmss(gaps[gaps.size / 2])}\n")
            sb.append("  longest  ${mmss(gaps.last())}\n")
        }
        if (hi.isNotEmpty()) {
            val since = (System.currentTimeMillis() - hi.last().ts) / 1000
            sb.append("Since last 10x+: ${mmss(since)}\n")
        }
        sb.append("\nLast 15 rounds\n")
        rs.takeLast(15).reversed().forEach {
            sb.append("${tf.format(it.ts)}  ")
            sb.mult(it.m)
            sb.append("\n")
        }
        sb.append("\nTime shown is when the round was captured (round end).\n")
    }

    private fun highs(sb: SpannableStringBuilder, rs: List<Round>) {
        val hi = rs.withIndex().filter { it.value.m >= 10 }
        sb.append("10x+ rounds: ${hi.size}\n\n")
        var prev = -1
        val lines = ArrayList<Triple<Round, Long, Int>>()
        hi.forEachIndexed { k, iv ->
            val gap = if (k == 0) -1L else (iv.value.ts - hi[k - 1].value.ts) / 1000
            val rounds = if (prev < 0) -1 else iv.index - prev
            prev = iv.index
            lines.add(Triple(iv.value, gap, rounds))
        }
        lines.takeLast(100).reversed().forEach { (r, gap, rounds) ->
            sb.append("${tf.format(r.ts)}  ")
            sb.mult(r.m)
            if (gap >= 0) sb.append("  +${mmss(gap)}  ($rounds rounds)")
            sb.append("\n")
        }
    }

    // pred = which rounds count as part of the streak; ok = (streak length, streak seconds) -> triggered
    private fun test(rs: List<Round>, pred: (Double) -> Boolean, ok: (Int, Long) -> Boolean): IntArray {
        var trig = 0
        var hit = 0
        fun cond(i: Int, j: Int) = ok(i - j + 1, (rs[i].ts - rs[j].ts) / 1000)
        for (i in 0 until rs.size - 1) {
            if (!pred(rs[i].m)) continue
            var j = i
            while (j > 0 && pred(rs[j - 1].m)) j--
            if (!cond(i, j)) continue
            if (i > j && cond(i - 1, j)) continue // count each streak once
            trig++
            if (rs[i + 1].m >= 10) hit++
        }
        return intArrayOf(trig, hit)
    }

    private fun ruleLine(sb: SpannableStringBuilder, name: String, r: IntArray, base: Double) {
        val rate = if (r[0] == 0) 0.0 else r[1] * 100.0 / r[0]
        sb.append("$name\n")
        sb.append("  triggered ${r[0]}x, next round was 10x+ ${r[1]}x (${String.format(Locale.US, "%.1f", rate)}%)\n")
        val verdict = when {
            r[0] < 30 -> "need 30+ triggers before this means anything"
            rate > base * 1.5 -> "above normal - re-check with more data"
            else -> "about the same as normal"
        }
        sb.append("  $verdict\n\n")
    }

    private fun rules(sb: SpannableStringBuilder, rs: List<Round>) {
        if (rs.size < 2) {
            sb.append("Log some rounds first.\n")
            return
        }
        val base = rs.count { it.m >= 10 } * 100.0 / rs.size
        sb.append("Normal 10x+ rate in your log: ${String.format(Locale.US, "%.1f", base)}%\n")
        sb.append("A rule only helps if its rate is clearly higher.\n\n")
        ruleLine(sb, "Blue (under 2x) for 2+ min", test(rs, { it < 2.0 }) { _, s -> s >= 120 }, base)
        ruleLine(sb, "4+ purples in a row over 2+ min", test(rs, { it >= 2.0 && it < 10.0 }) { c, s -> c >= 4 && s >= 120 }, base)
        var t = 0
        var hit = 0
        for (i in 0 until rs.size - 1) {
            if (rs[i].m <= 1.0) {
                t++
                if (rs[i + 1].m >= 10) hit++
            }
        }
        ruleLine(sb, "1.00x crash", intArrayOf(t, hit), base)
    }
}
