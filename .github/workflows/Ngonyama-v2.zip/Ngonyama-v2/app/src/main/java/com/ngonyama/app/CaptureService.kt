package com.ngonyama.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class CaptureService : AccessibilityService() {
    private var lastCapture = 0L
    private var lastCheck = 0L
    private val rx = Regex("^(\\d+(?:\\.\\d+)?)\\s*[xX]$")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val now = System.currentTimeMillis()
        if (now - lastCapture < 5000) return
        if (now - lastCheck < 300) return
        lastCheck = now
        val root = rootInActiveWindow ?: return
        val texts = ArrayList<String>()
        collect(root, texts, 0)
        if (texts.none { it.contains("FLEW AWAY", ignoreCase = true) }) return
        val m = texts.firstNotNullOfOrNull { rx.find(it.trim())?.groupValues?.get(1)?.toDoubleOrNull() }
            ?: return
        lastCapture = now
        Store.add(this, Round(now, m))
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 40) return
        n.text?.let { out.add(it.toString()) }
        n.contentDescription?.let { out.add(it.toString()) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() {}
}
